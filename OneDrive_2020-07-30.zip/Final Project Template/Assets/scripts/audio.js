function pageload() {

    let navlink = document.querySelectorAll('#teamlogos img');
    let blues = document.querySelector('#bluesaudio');
    let cards = document.querySelector('#cardsaudio');

    navlink[0].addEventListener('click', () => {
        cards.play();
        cards.controls = true;
    });
    navlink[1].addEventListener('click', () => {
        blues.play();
        blues.controls = true;
    });

}