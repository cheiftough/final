
function locationload() {

map = document.querySelector('#map').getElementsByTagName('iframe');

link1 = document.querySelector('#link1');
link2 = document.querySelector('#link2');
link3 = document.querySelector('#link3');
link4 = document.querySelector('#link4');
link5 = document.querySelector('#link5');
link6 = document.querySelector('#link6');
link7 = document.querySelector('#link7');

link1.addEventListener('click', () => {
    changeLocation('l1');
});
link2.addEventListener('click', () => {
    changeLocation('l2');
});
link3.addEventListener('click', () => {
    changeLocation('l3');
});
link4.addEventListener('click', () => {
    changeLocation('l4');
});
link5.addEventListener('click', () => {
    changeLocation('l5');
});
link6.addEventListener('click', () => {
    changeLocation('l6');
});
link7.addEventListener('click', () => {
    changeLocation('l7');
});

}


function changeLocation(link) {

    let url = "";

    switch (link) {


        case 'l1':
            url = "https://www.google.com/maps/embed/v1/place?key=AIzaSyDnIA24h7-1T8JCqA4cZWwqzfChyh7LDu0&q=ballpark+village";
            break;

        case 'l2':
            url = "https://www.google.com/maps/embed/v1/place?key=AIzaSyDnIA24h7-1T8JCqA4cZWwqzfChyh7LDu0&q=st.+louis+zoo";
            break;

        case 'l3':
            url = "https://www.google.com/maps/embed/v1/place?key=AIzaSyDnIA24h7-1T8JCqA4cZWwqzfChyh7LDu0&q=aquarium+union+station";
            break;

        case 'l4':
            url = "https://www.google.com/maps/embed/v1/place?key=AIzaSyDnIA24h7-1T8JCqA4cZWwqzfChyh7LDu0&q=arch+national+park";
            break;

        case 'l5':
            url = "https://www.google.com/maps/embed/v1/place?key=AIzaSyDnIA24h7-1T8JCqA4cZWwqzfChyh7LDu0&q=missouri+botanical+garden";
            break;

        case 'l6':
            url = "https://www.google.com/maps/embed/v1/place?key=AIzaSyDnIA24h7-1T8JCqA4cZWwqzfChyh7LDu0&q=laumeier+sculpture+park";
            break;

        case 'l7':
            url = "https://www.google.com/maps/embed/v1/place?key=AIzaSyDnIA24h7-1T8JCqA4cZWwqzfChyh7LDu0&q=city+museum+st.+louis";
            break;

        default:
            url = "https://www.google.com/maps/embed/v1/place?key=AIzaSyDnIA24h7-1T8JCqA4cZWwqzfChyh7LDu0&q=st.+louis";
    }

    document.querySelector('#frame').setAttribute('src', url);
}